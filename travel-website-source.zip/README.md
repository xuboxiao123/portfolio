Travel website frontend — undergraduate Year 2 coursework (2023–2024).

Original HTML/CSS/JavaScript sources. Includes destination pages, accommodation, reviews and trip planning. No backend or live booking integration is claimed. Original media and music are not bundled; source image references require the original ../img folder. Third-party assets remain with their owners.
