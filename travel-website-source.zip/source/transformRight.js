function transformRight(){
						var buttons = document.querySelectorAll(".b1");
						
						    buttons.forEach(function (button) {
						      var currentMargin = window.getComputedStyle(button).marginLeft;
						      var currentMarginValue = parseFloat(currentMargin);
						      button.style.marginLeft = currentMarginValue - 50 + "px";
							  
						    });
						var a= document.querySelector("#BLeft");
						if(a){
							a.style.display="block";
						}
						var b= document.querySelector("#BRight");
						if(b){
									  b.style.display="none";
						}
                    }
