function transformLeft(){
	var buttons = document.querySelectorAll(".b1");
	
	    buttons.forEach(function (button) {
	      var currentMargin = window.getComputedStyle(button).marginLeft;
	      var currentMarginValue = parseFloat(currentMargin);
	      button.style.marginLeft = currentMarginValue + 50 + "px";
		  });
	      var a= document.querySelector("#BRight");
		  if(a){
			  a.style.display="block";
		  }
		  var b= document.querySelector("#BLeft");
		  
		  	b.style.display="none";
		  
}