
		var checkedID = null;
		function Nature(){
		var a = document.querySelector("#Nature");
		if(checkedID !=null){
		  checkedID.style.backgroundColor = "white";
		  checkedID.style.color= "black";					 
		}
		 a.style.backgroundColor = "black";
		  a.style.color= "white";
		  checkedID  =a;
		var b = document.querySelector("#Title1");
		b.innerHTML="自然景观";
		var c = document.querySelector("#p1");
		var s = document.querySelector("#area");
		var judge = s.value;
		var t2h1 = document.querySelector("#t2h1");
			var t2a = document.querySelector("#t2a");
			var t2p = document.querySelector("#t2p");
			var t2p1 = document.querySelector("#t2p1");
			var t2p2 = document.querySelector("#t2p2");
			var t2p3 = document.querySelector("#t2p3");
			var t2p4 = document.querySelector("#t2p4");
			var t2p5 = document.querySelector("#t2p5");
			
			var img1 = document.querySelector("#img1");
			var img2 = document.querySelector("#img2");
			var img3 = document.querySelector("#img3");
			var img4 = document.querySelector("#img7");
			var img5 = document.querySelector("#img8");
			var img6 = document.querySelector("#img9");
			var img7 = document.querySelector("#img10");
			var img8 = document.querySelector("#img11");
			
			var t2h2 = document.querySelector("#t2h2");
			var t2h3 = document.querySelector("#t2h3");
			var t2h4 = document.querySelector("#t2h4");
			var t2h5 = document.querySelector("#t2h5");
			var t2h6 = document.querySelector("#t2h6");
			
			var a1 = document.querySelector("#a1");
			var a2 = document.querySelector("#a2");
			var a3 = document.querySelector("#a3");
			var a4 = document.querySelector("#a4");
			var a5 = document.querySelector("#a5");
		
		if(judge=="World"){	
			
		c.innerHTML="当提到自然景观，新西兰是一个不可错过的目的地。这个令人叹为观止的南太平洋岛国以其宏伟的自然奇观而闻名，提供了令人难以置信的独特体验。新西兰的自然景观多种多样，从壮观的雪峰到郁郁葱葱的丛林和宁静的湖泊，无一不让人陶醉 在南岛，弗兰茨·约瑟夫冰川和福克斯冰川展现了大自然的震撼力，令人惊叹的冰川景观是摄影爱好者和冒险者的天堂。而北岛的等福依湖则以其湛蓝的湖水和周围的原始森林而著称，是一个宁静而宜人的地方，适合放松身心";
		

		img1.src="../img/NatureImg1.png";
		img2.src="../img/NatureImg2.png";
		img3.src="../img/NatureImg3.png";
		img4.src="../img/NatureImg4.png";
		img5.src="../img/NatureImg5.png";
		img6.src="../img/NatureImg6.png";
		img7.src="../img/NatureImg7.png";
		img8.src="../img/NatureImg8.png";
		
		
		t2h1.innerHTML ="New Zealand";
		t2a.innerHTML="New Zealand";
		t2p.innerHTML="在这片神奇的土地上，您将被带入一个充满冒险和美丽的世界。新西兰以其独特而多样的自然风光而令人瞩目。首先，我们引领您探索南岛的南阿尔卑斯山脉，这里有雄伟的峰峦、壮丽的冰川和宛如仙境的湖泊，如皇后镇旁的瓦卡蒂普湖。北岛同样令人屏息，其火山地形在特卡波国家公园中展现无遗。独特的地热景观、草原和原始森林构成了这片土地的独特之美。罗托鲁瓦地区的温泉和冒着热气的泥浆池让人仿佛进入了一个神秘的仙境。沿着海岸线漫步，您将被北岛的贝伯湾以及南岛的凯库拉海岸所迷住。金黄色的沙滩、巍峨的悬崖和清澈的海水将为您打造出一幅绝美的海滨画卷。在新西兰，不仅有大自然的鬼斧神工，还有与之相伴的多彩鸟类和独特的动植物。在几个国家公园中，您将有机会近距离接触这些生态奇迹。无论您是喜欢户外活动的冒险家，还是寻求宁静放松的度假者，新西兰都能满足您的期待。我们的旅游网站将为您提供详尽的旅行信息、行程规划和风景名胜推荐，助您在这片自然乐园中度过一段难忘的时光。准备好迎接一场前所未有的冒险吧！";
		t2h2.innerHTML = "里约热内卢";
		t2h3.innerHTML ="夏威夷";
		t2h4.innerHTML ="日本";
		t2h5.innerHTML ="法国";
		t2h6.innerHTML ="希腊";
		a1.innerHTML = "里约热内卢基督像";
		a2.innerHTML = "欧胡岛";
		a3.innerHTML ="东京塔";
		a4.innerHTML ="罗马广场";
		a5.innerHTML ="伊拉克利翁考古博物馆";
		t2p1.innerHTML="里约热内卢基督像是一座举世闻名的宗教雕塑，坐落于巴西里约热内卢的科尔科瓦多山上。这座雕像是巴西最著名的象征之一，也是世界上最大的耶稣基督雕像之一。雕像高约30米，翼展约28米，站立在700米高的科尔科瓦多山峰上，俯瞰着整个里约热内卢市区和瓜纳巴拉湾。基督像不仅是宗教象征，也代表着宽容、和平和巴西人民的信仰。这座雕像象征着基督的神圣形象，同时也是里约热内卢市的标志之一。从基督像所在的科尔科瓦多山上，游客可以欣赏到令人叹为观止的全景，包括壮丽的海滩、城市和热带雨林。日出和日落时分，雕像会在夕阳的映照下呈现出令人心醉的景色。里约热内卢基督像以其宏伟的姿态、壮丽的景色和深厚的文化内涵，吸引着全球各地的游客，成为南美洲最令人向往的旅游胜地之一。";
		t2p2.innerHTML="欧胡岛（Oahu）是夏威夷群岛中最繁华的岛屿之一，以其美丽的自然风光、悠久的历史和丰富的文化而闻名。首府檀香山坐落在岛上，是夏威夷州最大的城市。岛上有著名的钻石头火山口，其宏伟的景色吸引着无数游客。在北岸，巴拉克·奥巴马总统童年度过的卡内奥赫湾（Kailua Bay）风光秀丽，是个度假胜地。欧胡岛不仅有美丽的海滩，如瓦埃纳海滩和卡拉瓦埃海滩，还有世界著名的冲浪胜地北岸，吸引着冲浪爱好者。珍珠港位于欧胡岛南部，是二战的历史见证地，游客可以参观那里的珍珠港纪念馆。";
		t2p3.innerHTML="这座塔的设计灵感来自于法国的埃菲尔铁塔，塔顶设有两个观景台，游客可以登上塔顶，俯瞰整个东京城市的美景。其中主观景台高约150米，顶层观景台则高达250米，提供360度全景视野，让游客欣赏到日本首都的壮丽景色，包括东京市区、富士山等地标景点。东京塔不仅是观光景点，也是电视和无线电广播的发射塔。每年吸引数以百万计的游客前来参观，尤其在夜晚，塔身灯火辉煌，为东京的夜空增添了璀璨的色彩，成为城市夜景的独特亮点。它不仅代表着东京现代化的一面，也是连接过去与现在的文化符号，是日本的重要地标之一。";
		t2p4.innerHTML="罗马广场（Piazza Navona）是意大利罗马市中心的一个古老而宏伟的广场，被认为是世界上最美丽的广场之一。广场呈长方形，原为多明我会修道院所在，如今以其独特的建筑和喷泉而著称。广场中央是巴洛克风格的四大河喷泉（Fountain of the Four Rivers），由著名雕塑家贝尔尼尼设计，象征着世界四大河的联结。在广场的两侧，有圣奥诺弗里公教堂（Sant'Agnese in Agone）和圣母百花大教堂（Santa Maria dei Fiori in Agone），两者的建筑风格都展现了罗马文艺复兴时期的巅峰。";
		t2p5.innerHTML="伊拉克利翁考古博物馆（The Iraq Museum）是位于伊拉克巴格达的一座重要博物馆，拥有世界上珍贵的古代文物和历史遗迹，展示了古代美索不达米亚文明的珍贵遗产。博物馆的收藏品包括来自巴比伦、亚述、苏美尔和其他古代文明的文物。其中最著名的是以色列首都耶路撒冷所得的约600块泥版，这些泥版被认为是世界上最古老的宗教文献之一，内容涵盖了早期的宗教和法律法规。不幸的是，在2003年伊拉克战争期间，伊拉克利翁考古博物馆遭到严重抢劫和破坏。大量珍贵文物被盗或毁坏，这次事件震惊了世界，并引发了国际社会对文化遗产保护的关注。";
		}
		
		if(judge=="China"){	
			
		c.innerHTML="在张家界，你将被千姿百态的石柱、峰丛、溪流和翠绿的树木所包围。其中最为著名的景点之一是被誉为“天下第一桥”的天门山玻璃栈道，你可以在这里俯瞰令人惊叹的峡谷风光。而黄龙洞则是一个地下溶洞奇观，内部钟乳石和石笋构成了一个梦幻般的地下仙境。此外，张家界还是中国武侠小说的发源地，这里的武陵源更是文学作品的灵感之源。你可以漫步在山水之间，感受古老传说的韵味，仿佛置身于仙境一般";}
		img3.src="../img/NatureImg3.png";
		img4.src="../img/NatureImg4.png";
		img5.src="../img/NatureImg5.png";
		img6.src="../img/NatureImg6.png";
		img7.src="../img/NatureImg7.png";
		img8.src="../img/NatureImg8.png";
		
		
		t2h1.innerHTML ="New Zealand";
		t2a.innerHTML="New Zealand";
		t2p.innerHTML="在这片神奇的土地上，您将被带入一个充满冒险和美丽的世界。新西兰以其独特而多样的自然风光而令人瞩目。首先，我们引领您探索南岛的南阿尔卑斯山脉，这里有雄伟的峰峦、壮丽的冰川和宛如仙境的湖泊，如皇后镇旁的瓦卡蒂普湖。北岛同样令人屏息，其火山地形在特卡波国家公园中展现无遗。独特的地热景观、草原和原始森林构成了这片土地的独特之美。罗托鲁瓦地区的温泉和冒着热气的泥浆池让人仿佛进入了一个神秘的仙境。沿着海岸线漫步，您将被北岛的贝伯湾以及南岛的凯库拉海岸所迷住。金黄色的沙滩、巍峨的悬崖和清澈的海水将为您打造出一幅绝美的海滨画卷。在新西兰，不仅有大自然的鬼斧神工，还有与之相伴的多彩鸟类和独特的动植物。在几个国家公园中，您将有机会近距离接触这些生态奇迹。无论您是喜欢户外活动的冒险家，还是寻求宁静放松的度假者，新西兰都能满足您的期待。我们的旅游网站将为您提供详尽的旅行信息、行程规划和风景名胜推荐，助您在这片自然乐园中度过一段难忘的时光。准备好迎接一场前所未有的冒险吧！";
		t2h2.innerHTML = "里约热内卢";
		t2h3.innerHTML ="夏威夷";
		t2h4.innerHTML ="日本";
		t2h5.innerHTML ="法国";
		t2h6.innerHTML ="希腊";
		a1.innerHTML = "里约热内卢基督像";
		a2.innerHTML = "欧胡岛";
		a3.innerHTML ="东京塔";
		a4.innerHTML ="罗马广场";
		a5.innerHTML ="伊拉克利翁考古博物馆";
		t2p1.innerHTML="里约热内卢基督像是一座举世闻名的宗教雕塑，坐落于巴西里约热内卢的科尔科瓦多山上。这座雕像是巴西最著名的象征之一，也是世界上最大的耶稣基督雕像之一。雕像高约30米，翼展约28米，站立在700米高的科尔科瓦多山峰上，俯瞰着整个里约热内卢市区和瓜纳巴拉湾。基督像不仅是宗教象征，也代表着宽容、和平和巴西人民的信仰。这座雕像象征着基督的神圣形象，同时也是里约热内卢市的标志之一。从基督像所在的科尔科瓦多山上，游客可以欣赏到令人叹为观止的全景，包括壮丽的海滩、城市和热带雨林。日出和日落时分，雕像会在夕阳的映照下呈现出令人心醉的景色。里约热内卢基督像以其宏伟的姿态、壮丽的景色和深厚的文化内涵，吸引着全球各地的游客，成为南美洲最令人向往的旅游胜地之一。";
		t2p2.innerHTML="欧胡岛（Oahu）是夏威夷群岛中最繁华的岛屿之一，以其美丽的自然风光、悠久的历史和丰富的文化而闻名。首府檀香山坐落在岛上，是夏威夷州最大的城市。岛上有著名的钻石头火山口，其宏伟的景色吸引着无数游客。在北岸，巴拉克·奥巴马总统童年度过的卡内奥赫湾（Kailua Bay）风光秀丽，是个度假胜地。欧胡岛不仅有美丽的海滩，如瓦埃纳海滩和卡拉瓦埃海滩，还有世界著名的冲浪胜地北岸，吸引着冲浪爱好者。珍珠港位于欧胡岛南部，是二战的历史见证地，游客可以参观那里的珍珠港纪念馆。";
		t2p3.innerHTML="这座塔的设计灵感来自于法国的埃菲尔铁塔，塔顶设有两个观景台，游客可以登上塔顶，俯瞰整个东京城市的美景。其中主观景台高约150米，顶层观景台则高达250米，提供360度全景视野，让游客欣赏到日本首都的壮丽景色，包括东京市区、富士山等地标景点。东京塔不仅是观光景点，也是电视和无线电广播的发射塔。每年吸引数以百万计的游客前来参观，尤其在夜晚，塔身灯火辉煌，为东京的夜空增添了璀璨的色彩，成为城市夜景的独特亮点。它不仅代表着东京现代化的一面，也是连接过去与现在的文化符号，是日本的重要地标之一。";
		t2p4.innerHTML="罗马广场（Piazza Navona）是意大利罗马市中心的一个古老而宏伟的广场，被认为是世界上最美丽的广场之一。广场呈长方形，原为多明我会修道院所在，如今以其独特的建筑和喷泉而著称。广场中央是巴洛克风格的四大河喷泉（Fountain of the Four Rivers），由著名雕塑家贝尔尼尼设计，象征着世界四大河的联结。在广场的两侧，有圣奥诺弗里公教堂（Sant'Agnese in Agone）和圣母百花大教堂（Santa Maria dei Fiori in Agone），两者的建筑风格都展现了罗马文艺复兴时期的巅峰。";
		t2p5.innerHTML="伊拉克利翁考古博物馆（The Iraq Museum）是位于伊拉克巴格达的一座重要博物馆，拥有世界上珍贵的古代文物和历史遗迹，展示了古代美索不达米亚文明的珍贵遗产。博物馆的收藏品包括来自巴比伦、亚述、苏美尔和其他古代文明的文物。其中最著名的是以色列首都耶路撒冷所得的约600块泥版，这些泥版被认为是世界上最古老的宗教文献之一，内容涵盖了早期的宗教和法律法规。不幸的是，在2003年伊拉克战争期间，伊拉克利翁考古博物馆遭到严重抢劫和破坏。大量珍贵文物被盗或毁坏，这次事件震惊了世界，并引发了国际社会对文化遗产保护的关注。";
		
		
		
		
		
		
		
		
		
		}
		function FOOD(){
			var a = document.querySelector("#FOOD");
			if(checkedID !=null){
			  checkedID.style.backgroundColor = "white";
			  checkedID.style.color= "black";					 
			}
			a.style.backgroundColor = "black";
			a.style.color= "white";
			checkedID  =a;
			var b = document.querySelector("#Title1");
			b.innerHTML="食物";
			var c = document.querySelector("#p1");
			var s = document.querySelector("#area");
			var judge = s.value;
			if(judge=="World"){
			c.innerHTML="在日本，寿司是一道代表性的美食，新鲜的生鱼片搭配嫩滑的米饭，让人享受到一种极致的口感。京都的樱花季节，除了美丽的花海，当地的樱花糕点更是一绝，精致的制作工艺和淡雅的口味成为了日本传统文化的一部分。若你钟情于浓郁的味道，那么意大利料理将让你陶醉。在罗马品尝到正宗的意式披萨，薄脆的皮搭配上丰富的番茄酱和芝士，每一口都是一场味觉盛宴。此外，意大利各地的面食也各具特色，从博洛尼亚的经典肉酱面到南部的橄榄油蒜泥面，每一种都是一场舌尖上的意式之旅。";}
			if(judge=="China"){
			c.innerHTML="当你踏足中国这片美食之地，无论是北方的深厚烹饪传统还是南方的精致口味，都会让你陶醉不已。在北京，别错过烤鸭，那香脆的皮和多汁的肉会令你回味无穷。而在上海，小笼包是一道不可忽视的美味，透着浓厚的鲜香汤汁，每一口都是一种享受。如果你来到四川，辣子鸡和麻辣火锅将挑战你的味蕾，那辣味的冲击让人欲罢不能。而广东的美食更是琳琅满目，从著名的广式早茶到各式各样的烧腊，总有一款能够迎合你的口味。在西安，你可以品尝到正宗的陕西拉面，香浓的汤底和劲道的面条仿佛让你置身于这座古老城市的历史中";}
	}
	function MSGJ(){
		var a = document.querySelector("#MSGJ");
		if(checkedID !=null){
		  checkedID.style.backgroundColor = "white";
		  checkedID.style.color= "black";					 
		}
		a.style.backgroundColor = "black";
		a.style.color= "white";
		checkedID  =a;
		var b = document.querySelector("#Title1");
		b.innerHTML="名胜古迹";
		var c = document.querySelector("#p1");
		var s = document.querySelector("#area");
		var judge = s.value;
		if(judge=="World"){
		c.innerHTML="欢迎踏上一场世界名胜古迹之旅，而位于希腊的雅典卫城将为你展开历史的篇章。作为世界上最著名的古老城市之一，雅典卫城是古希腊文明的象征，其气势恢宏的神庙和古老的遗迹令人惊叹。希腊神话中的众神与英雄在这里留下了永恒的足迹，而帕台农神庙、艾瑞克修斯神庙等建筑更是代表了古代建筑艺术的巅峰。若你对古罗马的壮丽历史感兴趣，那么意大利的罗马斗兽场将让你感受到时光的沧桑。这个古老的竞技场见证了古罗马时代的辉煌，如今它依旧屹立在罗马市中心，为游客们展现了古代罗马娱乐的盛况。漫步在斗兽场内，仿佛能够聆听到古老的呼喊声和战马蹄声的回响...";}
		if(judge=="China"){
			c.innerHTML="当提及中国的名胜古迹，不得不提的是中国的万里长城。作为世界七大奇迹之一，长城承载着中国悠久的历史与文化。其蜿蜒曲折的身影横跨山川，将你带入了几千年前的宏伟壮丽。从始建于秦朝的兵家必争之地到明朝的重要防线，长城见证了中国历史的沧桑变迁。而在北京附近的八达岭、慕田峪等长城段落，你可以近距离感受其雄伟壮观，俯瞰群山连绵、壮丽景色。。。";}
			}
		
		
	
	function amusement(){
		var a = document.querySelector("#amusement");
		if(checkedID !=null){
		  checkedID.style.backgroundColor = "white";
		  checkedID.style.color= "black";					 
		}
		a.style.backgroundColor = "black";
		a.style.color= "white";
		checkedID  =a;
		var b = document.querySelector("#Title1");
		b.innerHTML="娱乐";
		var c = document.querySelector("#p1");
		var s = document.querySelector("#area");
		var judge = s.value;
		if(judge=="World"){
		c.innerHTML="骑行爱好者也能在荷兰找到天堂。荷兰拥有广袤的自行车道和风景宜人的乡村景观，让你在轻松自在的骑行中领略风车、郁金香田园和宁静的运河风光。对于喜爱雪地运动的人来说，瑞士的阿尔卑斯山区是滑雪胜地的代名词。从翻滚的雪花到高山美景，你将在瑞士的滑雪胜地找到世界级的雪道和设施。若想在海上尽情享受，墨西哥的坎昆或许是你的理想之选。坎昆拥有碧海蓝天，提供丰富多样的水上活动，从深潜到帆船嬉戏，都能在这里轻松体验。";}
		if(judge=="China"){
		c.innerHTML="对于喜欢感受风驰电掣的快感的旅行者，中国的骑行之旅绝对是不可错过的。从云南丽江的丽江至香格里拉的香格里拉环线，到新疆的喀纳斯湖畔，沿途风光如画，让你在骑行的过程中领略中国的多样风情。如果冰雪世界是你向往的，那么中国的滑雪胜地不容错过。位于北京的崇礼滑雪场是2022年冬奥会的主场地，这里有丰富的滑雪资源和设施，无论是初学者还是高手都能在这里找到适合自己的挑战。对于喜欢海上冒险的人来说，海南的三亚是一个绝佳选择。这里有丰富多样的海上活动，从激情刺激的帆板冲浪到宁静惬意的海钓，满足了不同游客的需求";}
		
		
		
	}
	
	


	