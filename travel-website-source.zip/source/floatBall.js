
  function toggleSearch() {
    const searchBox = document.querySelector('.search-box');
    searchBox.focus();
  }

