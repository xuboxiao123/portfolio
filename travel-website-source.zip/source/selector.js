var checkedID = null;
var checkedID2 = null;
var a1=document.querySelector("whitep1");
var b1=document.querySelector("whitep2");
function resetStyles() {
  if (checkedID !== null && checkedID.style) {
    checkedID.style.backgroundColor = "rgba(0, 0, 0, 0)";
    checkedID.style.color = "white";
    if (checkedID2 !== null && checkedID2.style) {
      checkedID2.style.display = "none";
    }
  }
}

function a() {
	var elementA = document.querySelector("#mudi");
	var elementB = document.querySelector("#jiudian");
	var elementC = document.querySelector("#canting");
	var elementD = document.querySelector("#zuche");
	var elementa = document.querySelector("#planWhite1");
	var elementb = document.querySelector("#planWhite2");
	var elementc = document.querySelector("#planWhite3");
	var elementd = document.querySelector("#planWhite4");
  resetStyles();
  if (elementA) {
    checkedID = elementA;
    checkedID2 = elementa;
    elementA.style.backgroundColor = "white";
    elementA.style.color = "black";
    if (elementa) {
      elementa.style.display = "block";
    }
  }
}

function b() {
	var elementA = document.querySelector("#mudi");
	var elementB = document.querySelector("#jiudian");
	var elementC = document.querySelector("#canting");
	var elementD = document.querySelector("#zuche");
	var elementa = document.querySelector("#planWhite1");
	var elementb = document.querySelector("#planWhite2");
	var elementc = document.querySelector("#planWhite3");
	var elementd = document.querySelector("#planWhite4");
  resetStyles();
  if (elementB) {
    checkedID = elementB;
    checkedID2 = elementb;
    elementB.style.backgroundColor = "white";
    elementB.style.color = "black";
    if (elementb) {
      elementb.style.display = "block";
    }
  }
}

function c() {
	var elementA = document.querySelector("#mudi");
	var elementB = document.querySelector("#jiudian");
	var elementC = document.querySelector("#canting");
	var elementD = document.querySelector("#zuche");
	var elementa = document.querySelector("#planWhite1");
	var elementb = document.querySelector("#planWhite2");
	var elementc = document.querySelector("#planWhite3");
	var elementd = document.querySelector("#planWhite4");
  resetStyles();
  if (elementC) {
    checkedID = elementC;
    checkedID2 = elementc;
    elementC.style.backgroundColor = "white";
    elementC.style.color = "black";
    if (elementc) {
      elementc.style.display = "block";
    }
  }
}

function d() {
	var elementA = document.querySelector("#mudi");
	var elementB = document.querySelector("#jiudian");
	var elementC = document.querySelector("#canting");
	var elementD = document.querySelector("#zuche");
	var elementa = document.querySelector("#planWhite1");
	var elementb = document.querySelector("#planWhite2");
	var elementc = document.querySelector("#planWhite3");
	var elementd = document.querySelector("#planWhite4");
  resetStyles();
  if (elementD) {
    checkedID = elementD;
    checkedID2 = elementd;
    elementD.style.backgroundColor = "white";
    elementD.style.color = "black";
    if (elementd) {
      elementd.style.display = "block";
    }
  }
}
