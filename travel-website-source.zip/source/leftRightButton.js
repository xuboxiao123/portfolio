var a = document.querySelector("#picbox");
	    var imageWidth = 475; 
	    var totalImages = 6; 
	
	    function right() {
	        var currentMargin = parseInt(a.style.marginLeft) || 0;
	        if (currentMargin - imageWidth <= -imageWidth * totalImages) {
	            a.style.marginLeft = "0px"; // 
	        } else {
	            a.style.marginLeft = (currentMargin - imageWidth) + "px";
	        }
	    }
	
	    function left() {
	        var currentMargin = parseInt(a.style.marginLeft) || 0;
	        if (currentMargin + imageWidth > 0) {
	            a.style.marginLeft = (-imageWidth * (totalImages - 1)) + "px"; // 
	        } else {
	            a.style.marginLeft = (currentMargin + imageWidth) + "px";
	        }
	    }